import React from "react";
import { Link } from "react-router-dom";
import Layout from "@/components/layout/Layout";

export default function SightingQuickForm() {
  console.info("[SightingQuickForm] mounted");
  return (
    <Layout>
      <div className="max-w-3xl mx-auto px-4 py-8">
        
      <div className="mb-4 text-sm">
        <Link to="/dashboard" className="text-sky-700 hover:underline">Dashboard</Link>
        <span className="mx-2 text-gray-400">/</span>
        <span className="text-gray-600">Add New Sighting</span>
      </div>
      <h1 className="text-2xl font-bold">Sighting Quick Form (Map‑free)</h1>
        <p className="text-sm text-muted-foreground mt-2" data-testid="alive">
          Route is alive. We will wire the full form and DB submit next.
        </p>
      </div>
    </Layout>
  );
}
