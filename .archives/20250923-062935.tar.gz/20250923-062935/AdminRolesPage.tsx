import React from 'react';
import { useUserRole } from '@/hooks/useUserRole';

export default function AdminRolesPage() {
  const { role } = useUserRole();

  if (role !== 'admin') {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-semibold mb-2">Admin Roles</h1>
        <p className="text-gray-600">You must be an admin to view this page.</p>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold mb-2">Admin Roles</h1>
      <p className="text-gray-600 mb-4">
        Manage users and roles. (Page re‑enabled; we’ll wire full tools next.)
      </p>
      {/* TODO: restore full roles UI here */}
    </div>
  );
}
